#ifndef STREAMER_H
#define STREAMER_H
#include <Arduino.h>
#include "../../sensors/index.h"


template <typename Parent> class Streamer{
  private:
    Listener handler = Listener(0);
    Parent* device;

  public:
    unsigned long startTime;
    bool active, autostart;
    bool use_protocol = false;
    int dt;
    
    Streamer(Parent* dev):
        device(dev){}

    void setup(){
        dt = (1.00/device->frequency)*1000;
        Serial.println("Frequency Set To " + String(device->frequency) + " Hz (sample time " + String(dt) + "ms)");

        if(autostart)
            active = true;
    }
    
    void handle(){
        static Listener timer = Listener(dt);

        if(!active || !timer.ready())
            return;

        if(use_protocol)
            printProtocol();
        else
            printStandard();
    }

    void set(const bool state){
        if(active == state)
            return;

        if(state)
            handler.reset();
        
        startTime = Time::get();
        active    = state;
    }

    void printStandard(){
        device->sensors.kernel.printStandard(*(device->telemetry.serial.uart), startTime);
    }

    void printProtocol(){
        device->sensors.kernel.printProtocol(*(device->telemetry.serial.uart));
    }
};

#endif
